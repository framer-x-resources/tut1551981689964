import { Data, animate, Override, Animatable } from 'framer'

const data = Data({ left: Animatable(1) })

export const Scale: Override = () => {
  return {
    left: data.left,
    onTap() {
      //   data.left.set(0.6)
      var move = Math.floor(Math.random() * 100)
      animate.spring(data.left, move)

      //   Math.floor(Math.random() * 100);     // returns a random integer from 0 to 99
    },
    onPan(e) {
      console.log('e', e)
    },
  }
}
